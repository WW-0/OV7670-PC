﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OV7670
{
    public partial class MainFrm : Form
    {
        SerialPort sp;   //声明一个串口类
        bool isSetProperty = false; //属性设置标志位
        bool isOpen = false;//串口是否打开标志
        bool start = false;//开始数据发送

        Bitmap OvImage = new Bitmap(240, 320);//新建一个宽为240，高为320的位图
        int number = 0;//图片编号
        public MainFrm()
        {
            InitializeComponent();

            this.MaximizeBox = false;//禁用最大化
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            //****************填充下拉菜单********************
            //1.检测可用串口
            foreach (string s in SerialPort.GetPortNames())
            {
                cbbSerialID.Items.Add(s);
            }
            //2.列出常用的波特率
            cbbBundRate.Items.Add("1200");
            cbbBundRate.Items.Add("2400");
            cbbBundRate.Items.Add("4800");
            cbbBundRate.Items.Add("9600");
            cbbBundRate.Items.Add("19200");
            cbbBundRate.Items.Add("115200");
            cbbBundRate.SelectedIndex = 5;//默认选中最后一个

            //3.列出常用的停止位
            cbbStopBits.Items.Add("1");
            cbbStopBits.Items.Add("1.5");
            cbbStopBits.Items.Add("2");
            cbbStopBits.SelectedIndex = 0;

            //4.列出常用的数据位
            cbbDataBits.Items.Add("8");
            cbbDataBits.Items.Add("7");
            cbbDataBits.Items.Add("6");
            cbbDataBits.Items.Add("5");
            cbbDataBits.SelectedIndex = 0;

            //5.列出常用的奇偶校验位
            cbbCheckBits.Items.Add("无");
            cbbCheckBits.Items.Add("奇检验");
            cbbCheckBits.Items.Add("偶检验");
            cbbCheckBits.SelectedIndex = 0;

            //禁用数据保存按钮
            btnSave.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
        }

        /// <summary>
        /// 打开串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpen_Click(object sender, EventArgs e)
        {
            //没有设置串口信息后才会设置串口信息
            if (!isSetProperty)
            {
                //设置当前串口信息
                SetPortProperty();
                isSetProperty = true;
            }

            //设置端口名称
            try
            {
                //根据串口状态打开或关闭
                if (!isOpen)
                {
                    //打开串口
                    sp.Open();
                    this.btnOpen.Text = "关闭串口";
                    this.cbbBundRate.Enabled = false;
                    this.cbbCheckBits.Enabled = false;
                    this.cbbDataBits.Enabled = false;
                    this.cbbSerialID.Enabled = false;
                    this.cbbStopBits.Enabled = false;
                    this.btnSave.Enabled = true;
                    this.button1.Enabled = true;
                    this.button2.Enabled = true;
                    isOpen = true;
                }
                else
                {
                    //关闭串口
                    btnOpen.Text = "打开串口";
                    isOpen = false;
                    this.cbbBundRate.Enabled = true;
                    this.cbbCheckBits.Enabled = true;
                    this.cbbDataBits.Enabled = true;
                    this.cbbSerialID.Enabled = true;
                    this.cbbStopBits.Enabled = true;
                    this.btnSave.Enabled = false;
                    this.button1.Enabled = false;
                    this.button2.Enabled = false;

                    //重设标志,重设串口的信息
                    isSetProperty = false;
                    Thread.Sleep(100);
                    sp.Close();
                }
            }
            catch (Exception ex)
            {
                //关闭串口
                sp.Close();
                this.btnOpen.Text = "打开串口";
                MessageBox.Show("串口操作失败：" + ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            OvImage.Save("save"+number+".bmp");
            number++;
            MessageBox.Show("图片保存成功", "信息");
        }

        /// <summary>
        /// 设置串口的属性
        /// </summary>
        private void SetPortProperty()
        {
            sp = new SerialPort();
            sp.PortName = cbbSerialID.Text.Trim();//设置串口名 
            sp.BaudRate = Convert.ToInt32(cbbBundRate.Text.Trim());//设置串口波特率  
            float f = Convert.ToSingle(cbbStopBits.Text.Trim());   //设置停止位  
            if (1.5 == f)
            {
                sp.StopBits = StopBits.OnePointFive;
            }
            else if (1 == f)
            {
                sp.StopBits = StopBits.One;
            }
            else if (2 == f)
            {
                sp.StopBits = StopBits.Two;
            }
            else
            {
                sp.StopBits = StopBits.One;
            }
            sp.DataBits = Convert.ToInt16(cbbDataBits.Text.Trim());//设置数据位  
            string s = cbbCheckBits.Text.Trim();//设置奇偶校验位  
            if (0 == s.CompareTo("无"))
            {
                sp.Parity = Parity.None;
            }
            else if (0 == s.CompareTo("奇校验"))
            {
                sp.Parity = Parity.Odd;
            }
            else if (0 == s.CompareTo("偶校验"))
            {
                sp.Parity = Parity.Even;
            }
            else
            {
                sp.Parity = Parity.None;
            }
            //设置串口数据到达执行的函数
            sp.DataReceived += Sp_DataReceived;
            //串口检测
            sp.PinChanged += Sp_PinChanged;
        }

        private void Sp_PinChanged(object sender, SerialPinChangedEventArgs e)
        {
            MessageBox.Show("串口拔出！");
        }

        /// <summary>
        /// 串口数据到达事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Sp_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string data;
            Color[][] colors = new Color[240][];

            Byte[] butter = new Byte[320*240*2];
  
            if (isOpen) //检测串口是否打开
            {
                try //可能会出现意想不到错误的代码区域
                {
                    if (sp.ReadLine().Equals("data:"))  //检测是否开始发送数据
                    {
                        start = true;      
                    }
                    if (start)  //开始读取数据
                    {
                        if (isOpen)
                        {
                            butter[0] = (byte)sp.ReadByte();
                            butter[1] = (byte)sp.ReadByte();
                            butter[2] = (byte)sp.ReadByte();
                            sp.Write(butter,0,3);
                           
                            //for (Int32 n=0; n<153600; n++)
                            //{
                            //    butter[n] = (byte)sp.ReadByte();
                            //}
                            //sp.DiscardInBuffer();    //清除串口接收缓冲区数据
                            //System.Threading.Thread.Sleep(25000);  //延迟100ms等待接收完成数据
                            //bytesParaLer = sp.BytesToRead;
                            //sp.Read(butter, 0, bytesParaLer);    //字符数组读取串口数据                     
                        }
                        else
                        {
                            return;
                        }
                        Int32 i = 0;
                        for (int Xcount = 0; Xcount < 240; Xcount++)
                        {
                            for (int Ycount = 0; Ycount < 320; Ycount++)
                            {
                                byte rr = (byte)(butter[i] & 0xf8);//byte和byte相与运算后，结果变为int
                                byte gg = (byte)((butter[i] << 5) | ((butter[i+1] & 0xe0) >> 3));
                                byte bb = (byte)(butter[i+1] << 3); //高位索引小，地位索引大
                                i += 2;
                                //补偿
                                rr = (byte)(rr | ((rr & 0x38) >> 3));
                                gg = (byte)(gg | ((gg & 0x0c) >> 2));
                                bb = (byte)(bb | ((bb & 0x38) >> 3));

                                OvImage.SetPixel(Xcount, Ycount, Color.FromArgb(rr, gg, bb));
                            }
                        }
                        this.pbImage.Image = OvImage;

                        //for (int Xcount = 0; Xcount < 240; Xcount++) //绘制图像(一列一列地绘制)
                        //{
                        //    if (isOpen)
                        //    {
                        //        data = sp.ReadLine(); //读一列
                        //        if (data.StartsWith("L"))//列有效
                        //        {
                        //            colors[bytesParaLer++] = RGBToBitmap(data.Substring(1));//从data的第一位开始取字符
                        //        }
                        //        else
                        //        {
                        //            bytesParaLer = 0;
                        //            return;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        return;
                        //    }
                        //}
                        //for (int Xcount = 0; Xcount < 240; Xcount++)
                        //    for (int Ycount = 0; Ycount < 320; Ycount++)
                        //    {
                        //        OvImage.SetPixel(Xcount, Ycount, colors[Xcount][Ycount]);
                        //    }
                        //this.pbImage.Image = OvImage;
                        start = false;//接收数据结束
                        
                    }
                }
                catch (Exception ex)
                {
                    return;
                }
            }
        }

        /// <summary>
        /// 退出之前关闭串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainFrm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (sp != null)
            {
                if (sp.IsOpen)
                {
                    sp.DiscardInBuffer();
                    sp.Close();
                }
                sp.Dispose(); //释放sp使用的资源
                sp = null; //销毁sp
            }
        }

        /// <summary>
        /// 图像数据显示
        /// </summary>
        /// <param name="data">字符串数据</param>
        /// <returns></returns>
        private Color[] RGBToBitmap(string data)
        {
            Color[] colors;
            //将十六进制字符串转换为字节数组
            byte[] hexData = hexStringToByte(data);//如0xF8EC 转换以后hexData[0]=0xF8,hexData[1]=0xEC
            //将RGB565转换为RGB三色数值
            colors = RGB565ToColor(hexData);
            return colors;
        }

        /// <summary>
        /// 将RGB565的值转换为颜色数组
        /// </summary>
        /// <param name="hexArray"></param>
        /// <returns></returns>
        private static Color[] RGB565ToColor(byte[] hexArray)
        {
            //两字节代表一个像素，故长度为一半
            Color[] colors = new Color[hexArray.Length / 2];
            //生成Color值
            for (int i = 0; i < hexArray.Length; i += 2)
            {
                //U16(565) to RGB:
                //byte bg_r_color = ((bg_color >> 11) & 0xff) << 3;
                //byte bg_g_color = ((bg_color >> 5) & 0x3f) << 2;
                //byte bg_b_color = (bg_color & 0x1f) << 2;


                byte rr = (byte)(hexArray[i] & 0xf8);//byte和byte相与运算后，结果变为int
                byte gg = (byte)((hexArray[i] << 5) | ((hexArray[i + 1] & 0xe0) >> 3));
                byte bb = (byte)(hexArray[i + 1] << 3); //高位索引小，地位索引大

                //补偿
                rr = (byte)(rr | ((rr & 0x38) >> 3));
                gg = (byte)(gg | ((gg & 0x0c) >> 2));
                bb = (byte)(bb | ((bb & 0x38) >> 3));

                //设置Color值
                colors[i / 2] = Color.FromArgb(rr, gg, bb);
            }
            return colors;
        }

        /// <summary>
        /// 把16进制字符串转换成字节数组
        /// </summary>
        /// <param name="hex"></param>
        /// <returns></returns>
        public static byte[] hexStringToByte(String hex)//单片机串口printf发送0xF8EC，是长度为4的字符串
        {
            int len = (hex.Length / 2);
            byte[] result = new byte[len];
            char[] achar = hex.ToCharArray();//将字符串变成字符数组 不含结束标志
            for (int i = 0; i < len; i++)
            {
                int pos = i * 2;
                result[i] = (byte)(toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
            }
            return result;
        }

        /// <summary>
        /// 将十六进制的字符转换为字节
        /// </summary>
        /// <param name="c">字符</param>
        /// <returns></returns>
        private static byte toByte(char c)//  'F'变成F
        {
            byte b = (byte)"0123456789ABCDEF".IndexOf(c);
            return b;
        }

        private void gbSerialConfig_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Byte[] sendtemp = new Byte[3];
            sendtemp[0] = 0x55;
            sendtemp[1] = 0x0D;
            sendtemp[2] = 0x0A;
            sp.Write(sendtemp,0,3);//发送字符串，偏移量，长度
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Byte[] sendtemp = new Byte[3];
            sendtemp[0] = 0x56;
            sendtemp[1] = 0x0D;
            sendtemp[2] = 0x0A;
            sp.Write(sendtemp, 0, 3);//发送字符串，偏移量，长度
        }
    }
}
